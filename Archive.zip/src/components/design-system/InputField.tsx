'use client'

import React, { useState } from 'react';
import { Eye, EyeOff } from 'lucide-react';

interface InputFieldProps {
  label: string;
  type?: 'text' | 'tel' | 'password' | 'email';
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  error?: string;
  disabled?: boolean;
  className?: string;
}

export function InputField({
  label,
  type = 'text',
  value,
  onChange,
  placeholder,
  error,
  disabled = false,
  className = ''
}: InputFieldProps) {
  const [showPassword, setShowPassword] = useState(false);

  const inputType = type === 'password' && showPassword ? 'text' : type;

  return (
    <div className={className}>
      <label className="block text-[12px] leading-[18px] text-[var(--text-muted)] mb-1">
        {label}
      </label>
      <div className="relative">
        <input
          type={inputType}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={placeholder}
          disabled={disabled}
          className={`w-full h-[52px] px-4 bg-white border-[1.5px] rounded-[8px] text-[16px] leading-[24px] transition-colors ${
            error
              ? 'border-[var(--semantic-error-500)] focus:border-[var(--semantic-error-500)]'
              : 'border-[var(--border-default)] focus:border-[var(--border-brand)]'
          } focus:outline-none disabled:opacity-50`}
        />
        {type === 'password' && (
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            className="absolute right-4 top-1/2 -translate-y-1/2 text-[var(--text-muted)]"
          >
            {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
          </button>
        )}
      </div>
      {error && (
        <p className="text-[12px] leading-[18px] text-[var(--text-error)] mt-1">
          {error}
        </p>
      )}
    </div>
  );
}
