'use client'

import React, { useState } from 'react';
import Image from 'next/image';
import { Card } from '@/components/design-system/Card';
import { Button } from '@/components/design-system/Button';
import { InputField } from '@/components/design-system/InputField';

export default function RegisterCredentials() {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = () => {
    const newErrors: Record<string, string> = {};

    if (!phone) {
      newErrors.phone = 'Nomor HP wajib diisi';
    } else if (phone.length < 10) {
      newErrors.phone = 'Nomor HP tidak valid';
    } else if (phone === '08111111111') {
      newErrors.phone = 'duplicate';
    }

    if (!password) {
      newErrors.password = 'Password wajib diisi';
    } else if (password.length < 8) {
      newErrors.password = 'Password minimal 8 karakter';
    }

    if (password !== confirmPassword) {
      newErrors.confirmPassword = 'Password tidak sama';
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    console.log('Submit registration → R-02 OTP');
  };

  return (
    <div className="min-h-screen bg-[var(--surface-page)] max-w-[375px] mx-auto flex flex-col">
      {/* Logo / Brand */}
      <div className="pt-12 pb-8 text-center">
        <div className="w-20 h-20 mx-auto mb-4 rounded-full overflow-hidden">
          <Image
            src="/gapai-logo.jpg"
            alt="Gapai"
            width={80}
            height={80}
            className="w-full h-full object-cover"
          />
        </div>
        <h2 className="mb-2">Selamat datang di Gapai</h2>
        <p className="text-[14px] text-[var(--text-secondary)]">
          Mulai perjalananmu bekerja di luar negeri
        </p>
      </div>

      <main className="flex-1 px-5 pb-8">
        <Card variant="default" className="mb-6">
          <div className="space-y-4">
            <InputField
              label="Nomor HP"
              type="tel"
              value={phone}
              onChange={(v) => { setPhone(v); setErrors((e) => ({ ...e, phone: '' })); }}
              placeholder="Contoh: 081234567890"
              error={errors.phone === 'duplicate' ? undefined : errors.phone}
            />
            {errors.phone === 'duplicate' && (
              <div className="flex items-center justify-between px-3 py-2.5 rounded-[8px] bg-red-50 border border-red-200 -mt-2">
                <p className="text-[13px] text-red-600">Nomor ini sudah terdaftar.</p>
                <button
                  onClick={() => console.log('Go to L-01 Login')}
                  className="text-[13px] font-semibold text-[var(--text-brand)] shrink-0 ml-2"
                >
                  Masuk
                </button>
              </div>
            )}

            <InputField
              label="Password"
              type="password"
              value={password}
              onChange={setPassword}
              placeholder="Minimal 8 karakter"
              error={errors.password}
            />

            <InputField
              label="Konfirmasi Password"
              type="password"
              value={confirmPassword}
              onChange={setConfirmPassword}
              placeholder="Ketik ulang password"
              error={errors.confirmPassword}
            />
          </div>
        </Card>

        <Button variant="primary" onClick={handleSubmit}>
          Lanjutkan
        </Button>

        <div className="text-center mt-6">
          <p className="text-[13px] text-[var(--text-secondary)]">
            Sudah punya akun?{' '}
            <button
              className="text-[var(--text-brand)] font-medium"
              onClick={() => console.log('Go to login')}
            >
              Masuk
            </button>
          </p>
        </div>

        <div className="text-center mt-8">
          <p className="text-[12px] leading-[18px] text-[var(--text-muted)]">
            Dengan mendaftar, kamu menyetujui{' '}
            <button className="text-[var(--text-brand)]">Syarat & Ketentuan</button>
            {' '}dan{' '}
            <button className="text-[var(--text-brand)]">Kebijakan Privasi</button>
          </p>
        </div>
      </main>
    </div>
  );
}
